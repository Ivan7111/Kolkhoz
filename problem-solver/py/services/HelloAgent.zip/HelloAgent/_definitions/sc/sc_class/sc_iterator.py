from sc_addr import ScAddr

class ScIterator3:
  def Next(self) -> bool:
    return False

  def IsValid(self) -> bool:
    return False

  def Get(self, idx: int) -> ScAddr:
    return ScAddr()


class ScIterator5:
  def Next(self) -> bool:
    return False

  def IsValid(self) -> bool:
    return False

  def Get(self, idx: int) -> ScAddr:
    return ScAddr()