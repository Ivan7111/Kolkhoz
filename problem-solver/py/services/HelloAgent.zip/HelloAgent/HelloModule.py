from common import ScModule, ScKeynodes, ScPythonEventType
from keynodes import Keynodes
from HelloAgent import HelloAgent
from FieldAgent import FieldAgent
from SimilarityAgent import SimilaritiesAgent
from FarmAgent import FarmAgent

from sc import *


class HelloModule(ScModule):

    def __init__(self):
        ScModule.__init__(
            self,
            ctx=__ctx__,
            cpp_bridge=__cpp_bridge__,
            keynodes=[
            ],
        )

    def OnInitialize(self, params):
        print('Initialize kolkhoz module')
        kHello = self.ctx.HelperResolveSystemIdtf("ReadDNAHere", ScType.NodeConst)
        kHello1 = self.ctx.HelperResolveSystemIdtf("FindCulture", ScType.NodeConst)
        kHello2 = self.ctx.HelperResolveSystemIdtf("SimilarContextOfUse", ScType.NodeConst)
        kHello3 = self.ctx.HelperResolveSystemIdtf("CreateFerm", ScType.NodeConst)
        agent = HelloAgent(self)
        agent1 = FieldAgent(self)
        agent2 = SimilaritiesAgent(self)
        agent3 = FarmAgent(self)
        agent.Register(kHello, ScPythonEventType.AddOutputEdge)
        agent1.Register(kHello1, ScPythonEventType.AddOutputEdge)
        agent2.Register(kHello2, ScPythonEventType.AddOutputEdge)
        agent3.Register(kHello3, ScPythonEventType.AddOutputEdge)

    def OnShutdown(self):
        print('Shutting down kolkhoz agents')


service = HelloModule()
service.Run()
