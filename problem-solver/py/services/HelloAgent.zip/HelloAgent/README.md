## Module

This is an example of module with python agent.

To learn more about creation of python agents  please follow this [link](http://ostis-dev.github.io/sc-machine/python/library/)